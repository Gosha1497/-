﻿using System;
namespace DelegateSample
{

    public delegate double Fun(double x);

    class Program
    {
        public static void Table(Fun F, double x, double b)
        {
            Console.WriteLine("----- X ----- Y -----");
            while (x <= b)
            {
                Console.WriteLine("| {0,8:0.000} | {1,8:0.000} |", x, F(x));
                x += 1;
            }
            Console.WriteLine("---------------------");
        }
        
        public static double MyFunc3(double x)
        {
            return x*x;
        }
        public static double MyFunc2(double x)
        {
            return Math.Sin(Math.Log(x));
        }
        

        static void Main(string[] args)
        {
            int a = Convert.ToInt32(Console.Read());


            Console.WriteLine("Функция х^2");
            Table(new Fun(MyFunc3),-2, 2);
            Console.WriteLine("Таблица функции Sin(x):");
            Table( Math.Sin , -2, 2);
        }
    }
}