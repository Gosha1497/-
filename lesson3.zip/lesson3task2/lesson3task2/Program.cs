﻿using System;

namespace lesson3task2
{
    class Program
    {
        static void Main(string[] args)
        {
            string result = String.Empty;
            int summa = 0;
            while (true)
            {
                Console.Write("Введите пожалуйста числа, или 0 чтобы завершить ввод: ");
                int number;
                int.TryParse(Console.ReadLine(), out number);
                if (number == 0) break;
                if (number % 2 == 1 && number > 0)
                { summa += number;
                    result += $"{number}";
                }
            }
            Console.WriteLine($"{result} {summa}");
        }
    }
}
