﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        static int GetRandom()
        {
        Random rnd = new Random();
            int value = rnd.Next(10);
        return value;
        }
        private void Button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Угадайте число от 1 до 10. Увы в данной реализации программы у вас есть одна попытка на одно число. При проверке, текущее число будет сброшено и появится новое.");
            
        }
        
        private void Label1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Любопытство взяло верх над разумом?))))");
        }
        private void Button2_Click(object sender, EventArgs e)
        {
            int answer = Convert.ToInt16(textBox1.Text);
            if (answer == GetRandom()) { MessageBox.Show("Вы одержали победу");}
            else if (answer < GetRandom()) { MessageBox.Show("Ваше число пока-что меньше, давайте это исправим -_0)"); }
            else if (answer > GetRandom()) { MessageBox.Show("Ваше число больше загаданного(. Но это поправимо"); }

        }
    }
}
